package com.example.helloenglish;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.view.View;
import android.widget.ImageButton;
import android.media.MediaPlayer;
import android.content.pm.ActivityInfo;

public class Menu_suara_number extends Activity implements
        MediaPlayer.OnCompletionListener {

    private ImageButton tombol_play;
    private ImageButton tombol_play_01;
    private ImageButton tombol_play_02;
    private ImageButton tombol_play_03;
    private ImageButton tombol_play_04;
    private ImageButton tombol_play_05;
    private ImageButton tombol_play_06;
    private ImageButton tombol_play_07;
    private ImageButton tombol_play_08;
    private ImageButton tombol_play_09;
    private ImageButton tombol_play_10;
    private ImageButton tombol_stop;
    private MediaPlayer MPlayer;
    private MediaPlayer MPlayer_01;
    private MediaPlayer MPlayer_02;
    private MediaPlayer MPlayer_03;
    private MediaPlayer MPlayer_04;
    private MediaPlayer MPlayer_05;
    private MediaPlayer MPlayer_06;
    private MediaPlayer MPlayer_07;
    private MediaPlayer MPlayer_08;
    private MediaPlayer MPlayer_09;
    private MediaPlayer MPlayer_10;
    private MediaPlayer MPlayer_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_suara_number);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        tombol_play_01 = (ImageButton) findViewById(R.id.Btn_01);
        tombol_play_02 = (ImageButton) findViewById(R.id.Btn_02);
        tombol_play_03 = (ImageButton) findViewById(R.id.Btn_03);
        tombol_play_04 = (ImageButton) findViewById(R.id.Btn_04);
        tombol_play_05 = (ImageButton) findViewById(R.id.Btn_05);
        tombol_play_06 = (ImageButton) findViewById(R.id.Btn_06);
        tombol_play_07 = (ImageButton) findViewById(R.id.Btn_07);
        tombol_play_08 = (ImageButton) findViewById(R.id.Btn_08);
        tombol_play_09 = (ImageButton) findViewById(R.id.Btn_09);
        tombol_play_10 = (ImageButton) findViewById(R.id.Btn_10);
        tombol_play = (ImageButton) findViewById(R.id.Btn_play);
        tombol_stop = (ImageButton) findViewById(R.id.Btn_stop);
        tombol_stop.setEnabled(false);

        aktif();

        tombol_play_01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_01();
            }
        });
        tombol_play_02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_02();
            }
        });
        tombol_play_03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_03();
            }
        });
        tombol_play_04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_04();
            }
        });
        tombol_play_05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_05();
            }
        });
        tombol_play_06.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_06();
            }
        });
        tombol_play_07.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_07();
            }
        });
        tombol_play_08.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_08();
            }
        });
        tombol_play_09.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_09();
            }
        });
        tombol_play_10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_10();
            }
        });
        tombol_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_123();
            }
        });
        tombol_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MPlayer.stop();
                try {
                    MPlayer.prepare();
                    MPlayer.seekTo(0);
                } catch (Throwable t) {
                    error_(t);
                }
                stop_all();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        stop_back();
        play_back();
    }

    private void TombolIsEnabled() {
        tombol_play.setEnabled(true);
        tombol_play_01.setEnabled(true);
        tombol_play_02.setEnabled(true);
        tombol_play_03.setEnabled(true);
        tombol_play_04.setEnabled(true);
        tombol_play_05.setEnabled(true);
        tombol_play_06.setEnabled(true);
        tombol_play_07.setEnabled(true);
        tombol_play_08.setEnabled(true);
        tombol_play_09.setEnabled(true);
        tombol_play_10.setEnabled(true);
    }

    private void play_01() {
        MPlayer_01.stop();
        try {
            MPlayer_01.prepare();
            MPlayer_01.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_01.start();
        tombol_play_01.setImageResource(R.drawable.item_01_suara);
        tombol_play_01.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_02() {
        MPlayer_02.stop();
        try {
            MPlayer_02.prepare();
            MPlayer_02.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_02.start();
        tombol_play_02.setImageResource(R.drawable.item_02_suara);
        tombol_play_02.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_03() {
        MPlayer_03.stop();
        try {
            MPlayer_03.prepare();
            MPlayer_03.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_03.start();
        tombol_play_03.setImageResource(R.drawable.item_03_suara);
        tombol_play_03.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_04() {
        MPlayer_04.stop();
        try {
            MPlayer_04.prepare();
            MPlayer_04.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_04.start();
        tombol_play_04.setImageResource(R.drawable.item_04_suara);
        tombol_play_04.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_05() {
        MPlayer_05.stop();
        try {
            MPlayer_05.prepare();
            MPlayer_05.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_05.start();
        tombol_play_05.setImageResource(R.drawable.item_05_suara);
        tombol_play_05.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_06() {
        MPlayer_06.stop();
        try {
            MPlayer_06.prepare();
            MPlayer_06.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_06.start();
        tombol_play_06.setImageResource(R.drawable.item_06_suara);
        tombol_play_06.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_07() {
        MPlayer_07.stop();
        try {
            MPlayer_07.prepare();
            MPlayer_07.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_07.start();
        tombol_play_07.setImageResource(R.drawable.item_07_suara);
        tombol_play_07.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_08() {
        MPlayer_08.stop();
        try {
            MPlayer_08.prepare();
            MPlayer_08.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_08.start();
        tombol_play_08.setImageResource(R.drawable.item_08_suara);
        tombol_play_08.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_09() {
        MPlayer_09.stop();
        try {
            MPlayer_09.prepare();
            MPlayer_09.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_09.start();
        tombol_play_09.setImageResource(R.drawable.item_09_suara);
        tombol_play_09.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_10() {
        MPlayer_10.stop();
        try {
            MPlayer_10.prepare();
            MPlayer_10.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_10.start();
        tombol_play_10.setImageResource(R.drawable.item_10_suara);
        tombol_play_10.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (tombol_stop.isEnabled()) {
            stop_all();
        }
    }

    @Override
    public void onCompletion(MediaPlayer MP) {
        stop_all();
    }

    private void play_123() {
        MPlayer_01.stop();
        MPlayer_02.stop();
        MPlayer_03.stop();
        MPlayer_04.stop();
        MPlayer_05.stop();
        MPlayer_06.stop();
        MPlayer_07.stop();
        MPlayer_08.stop();
        MPlayer_09.stop();
        MPlayer_10.stop();
        MPlayer.stop();
        try {
            MPlayer.prepare();
            MPlayer.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer.setLooping(true);
        MPlayer.start();
        tombol_play.setEnabled(false);
        tombol_stop.setEnabled(true);
        tombol_play_01.setEnabled(false);
        tombol_play_02.setEnabled(false);
        tombol_play_03.setEnabled(false);
        tombol_play_04.setEnabled(false);
        tombol_play_05.setEnabled(false);
        tombol_play_06.setEnabled(false);
        tombol_play_07.setEnabled(false);
        tombol_play_08.setEnabled(false);
        tombol_play_09.setEnabled(false);
        tombol_play_10.setEnabled(false);
    }

    private void stop_all() {
        tombol_stop.setEnabled(false);
        tombol_play_01.setImageResource(R.drawable.item_01_menu);
        tombol_play_02.setImageResource(R.drawable.item_02_menu);
        tombol_play_03.setImageResource(R.drawable.item_03_menu);
        tombol_play_04.setImageResource(R.drawable.item_04_menu);
        tombol_play_05.setImageResource(R.drawable.item_05_menu);
        tombol_play_06.setImageResource(R.drawable.item_06_menu);
        tombol_play_07.setImageResource(R.drawable.item_07_menu);
        tombol_play_08.setImageResource(R.drawable.item_08_menu);
        tombol_play_09.setImageResource(R.drawable.item_09_menu);
        tombol_play_10.setImageResource(R.drawable.item_10_menu);
        try {
            TombolIsEnabled();
        } catch (Throwable t) {
            error_(t);
        }

    }

    private void aktif() {
        try {
            MPlayer = MediaPlayer.create(this, R.raw.s123);
            MPlayer.setOnCompletionListener(this);
            MPlayer_01 = MediaPlayer.create(this, R.raw.s01);
            MPlayer_01.setOnCompletionListener(this);
            MPlayer_02 = MediaPlayer.create(this, R.raw.s02);
            MPlayer_02.setOnCompletionListener(this);
            MPlayer_03 = MediaPlayer.create(this, R.raw.s03);
            MPlayer_03.setOnCompletionListener(this);
            MPlayer_04 = MediaPlayer.create(this, R.raw.s04);
            MPlayer_04.setOnCompletionListener(this);
            MPlayer_05 = MediaPlayer.create(this, R.raw.s05);
            MPlayer_05.setOnCompletionListener(this);
            MPlayer_06 = MediaPlayer.create(this, R.raw.s06);
            MPlayer_06.setOnCompletionListener(this);
            MPlayer_07 = MediaPlayer.create(this, R.raw.s07);
            MPlayer_07.setOnCompletionListener(this);
            MPlayer_08 = MediaPlayer.create(this, R.raw.s08);
            MPlayer_08.setOnCompletionListener(this);
            MPlayer_09 = MediaPlayer.create(this, R.raw.s09);
            MPlayer_09.setOnCompletionListener(this);
            MPlayer_10 = MediaPlayer.create(this, R.raw.s10);
            MPlayer_10.setOnCompletionListener(this);
            MPlayer_back = MediaPlayer.create(this, R.raw.backsound_number);
        } catch (Throwable t) {
            error_(t);
        }
        TombolIsEnabled();
    }

    private void play_back() {
        if (MPlayer_back != null && !MPlayer_back.isPlaying()) {
            MPlayer_back.setLooping(true);
            MPlayer_back.start();
        } else {
            MPlayer_back.setLooping(true);
        }
    }

    private void stop_for_back() {
        MPlayer_back.stop();
        try {
            MPlayer_back.prepare();
            MPlayer_back.seekTo(0);

        } catch (Throwable t) {
            error_(t);
        }
    }

    private void stop_back() {
        if (MPlayer_back.isPlaying()) {
            stop_for_back();
        }
    }

    private void error_(Throwable t) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Failed!").setMessage(t.toString())
                .setPositiveButton("OK", null).show();
    }

    @Override
    public void onBackPressed() {
        if (MPlayer.isPlaying() || MPlayer_back.isPlaying()) {
            MPlayer.stop();
            stop_back();
        }
        finish();
    }
}
