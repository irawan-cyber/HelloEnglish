package com.example.helloenglish;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.view.View;
import android.widget.ImageButton;
import android.media.MediaPlayer;
import android.content.pm.ActivityInfo;

public class Menu_suara_abc extends Activity implements
        MediaPlayer.OnCompletionListener {

    private ImageButton tombol_play;
    private ImageButton tombol_play_a;
    private ImageButton tombol_play_b;
    private ImageButton tombol_play_c;
    private ImageButton tombol_play_d;
    private ImageButton tombol_play_e;
    private ImageButton tombol_play_f;
    private ImageButton tombol_play_g;
    private ImageButton tombol_play_h;
    private ImageButton tombol_play_i;
    private ImageButton tombol_play_j;
    private ImageButton tombol_play_k;
    private ImageButton tombol_play_l;
    private ImageButton tombol_play_m;
    private ImageButton tombol_play_n;
    private ImageButton tombol_play_o;
    private ImageButton tombol_play_p;
    private ImageButton tombol_play_q;
    private ImageButton tombol_play_r;
    private ImageButton tombol_play_s;
    private ImageButton tombol_play_t;
    private ImageButton tombol_play_u;
    private ImageButton tombol_play_v;
    private ImageButton tombol_play_w;
    private ImageButton tombol_play_x;
    private ImageButton tombol_play_y;
    private ImageButton tombol_play_z;
    private ImageButton tombol_stop;
    private MediaPlayer MPlayer;
    private MediaPlayer MPlayer_a;
    private MediaPlayer MPlayer_b;
    private MediaPlayer MPlayer_c;
    private MediaPlayer MPlayer_d;
    private MediaPlayer MPlayer_e;
    private MediaPlayer MPlayer_f;
    private MediaPlayer MPlayer_g;
    private MediaPlayer MPlayer_h;
    private MediaPlayer MPlayer_i;
    private MediaPlayer MPlayer_j;
    private MediaPlayer MPlayer_k;
    private MediaPlayer MPlayer_l;
    private MediaPlayer MPlayer_m;
    private MediaPlayer MPlayer_n;
    private MediaPlayer MPlayer_o;
    private MediaPlayer MPlayer_p;
    private MediaPlayer MPlayer_q;
    private MediaPlayer MPlayer_r;
    private MediaPlayer MPlayer_s;
    private MediaPlayer MPlayer_t;
    private MediaPlayer MPlayer_u;
    private MediaPlayer MPlayer_v;
    private MediaPlayer MPlayer_w;
    private MediaPlayer MPlayer_x;
    private MediaPlayer MPlayer_y;
    private MediaPlayer MPlayer_z;
    private MediaPlayer MPlayer_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_suara_abc);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        tombol_play_a = (ImageButton) findViewById(R.id.Btn_a);
        tombol_play_b = (ImageButton) findViewById(R.id.Btn_b);
        tombol_play_c = (ImageButton) findViewById(R.id.Btn_c);
        tombol_play_d = (ImageButton) findViewById(R.id.Btn_d);
        tombol_play_e = (ImageButton) findViewById(R.id.Btn_e);
        tombol_play_f = (ImageButton) findViewById(R.id.Btn_f);
        tombol_play_g = (ImageButton) findViewById(R.id.Btn_g);
        tombol_play_h = (ImageButton) findViewById(R.id.Btn_h);
        tombol_play_i = (ImageButton) findViewById(R.id.Btn_i);
        tombol_play_j = (ImageButton) findViewById(R.id.Btn_j);
        tombol_play_k = (ImageButton) findViewById(R.id.Btn_k);
        tombol_play_l = (ImageButton) findViewById(R.id.Btn_l);
        tombol_play_m = (ImageButton) findViewById(R.id.Btn_m);
        tombol_play_n = (ImageButton) findViewById(R.id.Btn_n);
        tombol_play_o = (ImageButton) findViewById(R.id.Btn_o);
        tombol_play_p = (ImageButton) findViewById(R.id.Btn_p);
        tombol_play_q = (ImageButton) findViewById(R.id.Btn_q);
        tombol_play_r = (ImageButton) findViewById(R.id.Btn_r);
        tombol_play_s = (ImageButton) findViewById(R.id.Btn_s);
        tombol_play_t = (ImageButton) findViewById(R.id.Btn_t);
        tombol_play_u = (ImageButton) findViewById(R.id.Btn_u);
        tombol_play_v = (ImageButton) findViewById(R.id.Btn_v);
        tombol_play_w = (ImageButton) findViewById(R.id.Btn_w);
        tombol_play_x = (ImageButton) findViewById(R.id.Btn_x);
        tombol_play_y = (ImageButton) findViewById(R.id.Btn_y);
        tombol_play_z = (ImageButton) findViewById(R.id.Btn_z);
        tombol_play = (ImageButton) findViewById(R.id.Btn_play);
        tombol_stop = (ImageButton) findViewById(R.id.Btn_stop);
        tombol_stop.setEnabled(false);

        aktif();

        tombol_play_a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_a();
            }
        });
        tombol_play_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_b();
            }
        });
        tombol_play_c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_c();
            }
        });
        tombol_play_d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_d();
            }
        });
        tombol_play_e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_e();
            }
        });
        tombol_play_f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_f();
            }
        });
        tombol_play_g.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_g();
            }
        });
        tombol_play_h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_h();
            }
        });
        tombol_play_i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_i();
            }
        });
        tombol_play_j.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_j();
            }
        });
        tombol_play_k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_k();
            }
        });
        tombol_play_l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_l();
            }
        });
        tombol_play_m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_m();
            }
        });
        tombol_play_n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_n();
            }
        });
        tombol_play_o.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_o();
            }
        });
        tombol_play_p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_p();
            }
        });
        tombol_play_q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_q();
            }
        });
        tombol_play_r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_r();
            }
        });
        tombol_play_s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_s();
            }
        });
        tombol_play_t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_t();
            }
        });
        tombol_play_u.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_u();
            }
        });
        tombol_play_v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_v();
            }
        });
        tombol_play_w.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_w();
            }
        });
        tombol_play_x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_x();
            }
        });
        tombol_play_y.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_y();
            }
        });
        tombol_play_z.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_z();
            }
        });

        tombol_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                play_abc();
            }
        });

        tombol_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MPlayer.stop();
                try {
                    MPlayer.prepare();
                    MPlayer.seekTo(0);
                } catch (Throwable t) {
                    error_(t);
                }
                stop_all();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        stop_back();
        play_back();
    }

    private void TombolIsEnabled() {
        tombol_play.setEnabled(true);
        tombol_play_a.setEnabled(true);
        tombol_play_b.setEnabled(true);
        tombol_play_c.setEnabled(true);
        tombol_play_d.setEnabled(true);
        tombol_play_e.setEnabled(true);
        tombol_play_f.setEnabled(true);
        tombol_play_g.setEnabled(true);
        tombol_play_h.setEnabled(true);
        tombol_play_i.setEnabled(true);
        tombol_play_j.setEnabled(true);
        tombol_play_k.setEnabled(true);
        tombol_play_l.setEnabled(true);
        tombol_play_m.setEnabled(true);
        tombol_play_n.setEnabled(true);
        tombol_play_o.setEnabled(true);
        tombol_play_p.setEnabled(true);
        tombol_play_q.setEnabled(true);
        tombol_play_r.setEnabled(true);
        tombol_play_s.setEnabled(true);
        tombol_play_t.setEnabled(true);
        tombol_play_u.setEnabled(true);
        tombol_play_v.setEnabled(true);
        tombol_play_w.setEnabled(true);
        tombol_play_x.setEnabled(true);
        tombol_play_y.setEnabled(true);
        tombol_play_z.setEnabled(true);
    }

    private void play_a() {
        MPlayer_a.stop();
        try {
            MPlayer_a.prepare();
            MPlayer_a.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_a.start();
        tombol_play_a.setImageResource(R.drawable.item_a_suara);
        tombol_play_a.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_b() {
        MPlayer_b.stop();
        try {
            MPlayer_b.prepare();
            MPlayer_b.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_b.start();
        tombol_play_b.setImageResource(R.drawable.item_b_suara);
        tombol_play_b.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_c() {
        MPlayer_c.stop();
        try {
            MPlayer_c.prepare();
            MPlayer_c.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_c.start();
        tombol_play_c.setImageResource(R.drawable.item_c_suara);
        tombol_play_c.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_d() {
        MPlayer_d.stop();
        try {
            MPlayer_d.prepare();
            MPlayer_d.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_d.start();
        tombol_play_d.setImageResource(R.drawable.item_d_suara);
        tombol_play_d.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_e() {
        MPlayer_e.stop();
        try {
            MPlayer_e.prepare();
            MPlayer_e.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_e.start();
        tombol_play_e.setImageResource(R.drawable.item_e_suara);
        tombol_play_e.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_f() {
        MPlayer_f.stop();
        try {
            MPlayer_f.prepare();
            MPlayer_f.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_f.start();
        tombol_play_f.setImageResource(R.drawable.item_f_suara);
        tombol_play_f.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_g() {
        MPlayer_g.stop();
        try {
            MPlayer_g.prepare();
            MPlayer_g.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_g.start();
        tombol_play_g.setImageResource(R.drawable.item_g_suara);
        tombol_play_g.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_h() {
        MPlayer_h.stop();
        try {
            MPlayer_h.prepare();
            MPlayer_h.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_h.start();
        tombol_play_h.setImageResource(R.drawable.item_h_suara);
        tombol_play_h.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_i() {
        MPlayer_i.stop();
        try {
            MPlayer_i.prepare();
            MPlayer_i.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_i.start();
        tombol_play_i.setImageResource(R.drawable.item_i_suara);
        tombol_play_i.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_j() {
        MPlayer_j.stop();
        try {
            MPlayer_j.prepare();
            MPlayer_j.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_j.start();
        tombol_play_j.setImageResource(R.drawable.item_j_suara);
        tombol_play_j.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_k() {
        MPlayer_k.stop();
        try {
            MPlayer_k.prepare();
            MPlayer_k.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_k.start();
        tombol_play_k.setImageResource(R.drawable.item_k_suara);
        tombol_play_k.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_l() {
        MPlayer_l.stop();
        try {
            MPlayer_l.prepare();
            MPlayer_l.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_l.start();
        tombol_play_l.setImageResource(R.drawable.item_l_suara);
        tombol_play_l.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_m() {
        MPlayer_m.stop();
        try {
            MPlayer_m.prepare();
            MPlayer_m.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_m.start();
        tombol_play_m.setImageResource(R.drawable.item_m_suara);
        tombol_play_m.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_n() {
        MPlayer_n.stop();
        try {
            MPlayer_n.prepare();
            MPlayer_n.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_n.start();
        tombol_play_n.setImageResource(R.drawable.item_n_suara);
        tombol_play_n.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_o() {
        MPlayer_o.stop();
        try {
            MPlayer_o.prepare();
            MPlayer_o.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_o.start();
        tombol_play_o.setImageResource(R.drawable.item_o_suara);
        tombol_play_o.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_p() {
        MPlayer_p.stop();
        try {
            MPlayer_p.prepare();
            MPlayer_p.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_p.start();
        tombol_play_p.setImageResource(R.drawable.item_p_suara);
        tombol_play_p.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_q() {
        MPlayer_q.stop();
        try {
            MPlayer_q.prepare();
            MPlayer_q.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_q.start();
        tombol_play_q.setImageResource(R.drawable.item_q_suara);
        tombol_play_q.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_r() {
        MPlayer_r.stop();
        try {
            MPlayer_r.prepare();
            MPlayer_r.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_r.start();
        tombol_play_r.setImageResource(R.drawable.item_r_suara);
        tombol_play_r.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_s() {
        MPlayer_s.stop();
        try {
            MPlayer_s.prepare();
            MPlayer_s.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_s.start();
        tombol_play_s.setImageResource(R.drawable.item_s_suara);
        tombol_play_s.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_t() {
        MPlayer_t.stop();
        try {
            MPlayer_t.prepare();
            MPlayer_t.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_t.start();
        tombol_play_t.setImageResource(R.drawable.item_t_suara);
        tombol_play_t.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_u() {
        MPlayer_u.stop();
        try {
            MPlayer_u.prepare();
            MPlayer_u.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_u.start();
        tombol_play_u.setImageResource(R.drawable.item_u_suara);
        tombol_play_u.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_v() {
        MPlayer_v.stop();
        try {
            MPlayer_v.prepare();
            MPlayer_v.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_v.start();
        tombol_play_v.setImageResource(R.drawable.item_v_suara);
        tombol_play_v.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_w() {
        MPlayer_w.stop();
        try {
            MPlayer_w.prepare();
            MPlayer_w.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_w.start();
        tombol_play_w.setImageResource(R.drawable.item_w_suara);
        tombol_play_w.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_x() {
        MPlayer_x.stop();
        try {
            MPlayer_x.prepare();
            MPlayer_x.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_x.start();
        tombol_play_x.setImageResource(R.drawable.item_x_suara);
        tombol_play_x.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_y() {
        MPlayer_y.stop();
        try {
            MPlayer_y.prepare();
            MPlayer_y.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_y.start();
        tombol_play_y.setImageResource(R.drawable.item_y_suara);
        tombol_play_y.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    private void play_z() {
        MPlayer_z.stop();
        try {
            MPlayer_z.prepare();
            MPlayer_z.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer_z.start();
        tombol_play_z.setImageResource(R.drawable.item_z_suara);
        tombol_play_z.setEnabled(false);
        tombol_stop.setEnabled(true);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (tombol_stop.isEnabled()) {
            stop_all();
        }
    }

    @Override
    public void onCompletion(MediaPlayer MP) {
        stop_all();
    }

    private void play_abc() {
        MPlayer_a.stop();
        MPlayer_b.stop();
        MPlayer_c.stop();
        MPlayer_d.stop();
        MPlayer_e.stop();
        MPlayer_f.stop();
        MPlayer_g.stop();
        MPlayer_h.stop();
        MPlayer_i.stop();
        MPlayer_j.stop();
        MPlayer_k.stop();
        MPlayer_l.stop();
        MPlayer_m.stop();
        MPlayer_n.stop();
        MPlayer_o.stop();
        MPlayer_p.stop();
        MPlayer_q.stop();
        MPlayer_r.stop();
        MPlayer_s.stop();
        MPlayer_t.stop();
        MPlayer_u.stop();
        MPlayer_v.stop();
        MPlayer_w.stop();
        MPlayer_x.stop();
        MPlayer_y.stop();
        MPlayer_z.stop();
        MPlayer.stop();
        try {
            MPlayer.prepare();
            MPlayer.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        stop_all();
        MPlayer.setLooping(true);
        MPlayer.start();
        tombol_play.setEnabled(false);
        tombol_stop.setEnabled(true);
        tombol_play_a.setEnabled(false);
        tombol_play_b.setEnabled(false);
        tombol_play_c.setEnabled(false);
        tombol_play_d.setEnabled(false);
        tombol_play_e.setEnabled(false);
        tombol_play_f.setEnabled(false);
        tombol_play_g.setEnabled(false);
        tombol_play_h.setEnabled(false);
        tombol_play_i.setEnabled(false);
        tombol_play_j.setEnabled(false);
        tombol_play_k.setEnabled(false);
        tombol_play_l.setEnabled(false);
        tombol_play_m.setEnabled(false);
        tombol_play_n.setEnabled(false);
        tombol_play_o.setEnabled(false);
        tombol_play_p.setEnabled(false);
        tombol_play_q.setEnabled(false);
        tombol_play_r.setEnabled(false);
        tombol_play_s.setEnabled(false);
        tombol_play_t.setEnabled(false);
        tombol_play_u.setEnabled(false);
        tombol_play_v.setEnabled(false);
        tombol_play_w.setEnabled(false);
        tombol_play_x.setEnabled(false);
        tombol_play_y.setEnabled(false);
        tombol_play_z.setEnabled(false);
    }

    private void stop_all() {
        tombol_stop.setEnabled(false);
        tombol_play_a.setImageResource(R.drawable.item_a_menu);
        tombol_play_b.setImageResource(R.drawable.item_b_menu);
        tombol_play_c.setImageResource(R.drawable.item_c_menu);
        tombol_play_d.setImageResource(R.drawable.item_d_menu);
        tombol_play_e.setImageResource(R.drawable.item_e_menu);
        tombol_play_f.setImageResource(R.drawable.item_f_menu);
        tombol_play_g.setImageResource(R.drawable.item_g_menu);
        tombol_play_h.setImageResource(R.drawable.item_h_menu);
        tombol_play_i.setImageResource(R.drawable.item_i_menu);
        tombol_play_j.setImageResource(R.drawable.item_j_menu);
        tombol_play_k.setImageResource(R.drawable.item_k_menu);
        tombol_play_l.setImageResource(R.drawable.item_l_menu);
        tombol_play_m.setImageResource(R.drawable.item_m_menu);
        tombol_play_n.setImageResource(R.drawable.item_n_menu);
        tombol_play_o.setImageResource(R.drawable.item_o_menu);
        tombol_play_p.setImageResource(R.drawable.item_p_menu);
        tombol_play_q.setImageResource(R.drawable.item_q_menu);
        tombol_play_r.setImageResource(R.drawable.item_r_menu);
        tombol_play_s.setImageResource(R.drawable.item_s_menu);
        tombol_play_t.setImageResource(R.drawable.item_t_menu);
        tombol_play_u.setImageResource(R.drawable.item_u_menu);
        tombol_play_v.setImageResource(R.drawable.item_v_menu);
        tombol_play_w.setImageResource(R.drawable.item_w_menu);
        tombol_play_x.setImageResource(R.drawable.item_x_menu);
        tombol_play_y.setImageResource(R.drawable.item_y_menu);
        tombol_play_z.setImageResource(R.drawable.item_z_menu);

        try {
            TombolIsEnabled();
        } catch (Throwable t) {
            error_(t);
        }

    }

    private void aktif() {
        try {
            MPlayer = MediaPlayer.create(this, R.raw.abc);
            MPlayer.setOnCompletionListener(this);
            MPlayer_a = MediaPlayer.create(this, R.raw.a);
            MPlayer_a.setOnCompletionListener(this);
            MPlayer_b = MediaPlayer.create(this, R.raw.b);
            MPlayer_b.setOnCompletionListener(this);
            MPlayer_c = MediaPlayer.create(this, R.raw.c);
            MPlayer_c.setOnCompletionListener(this);
            MPlayer_d = MediaPlayer.create(this, R.raw.d);
            MPlayer_d.setOnCompletionListener(this);
            MPlayer_e = MediaPlayer.create(this, R.raw.e);
            MPlayer_e.setOnCompletionListener(this);
            MPlayer_f = MediaPlayer.create(this, R.raw.f);
            MPlayer_f.setOnCompletionListener(this);
            MPlayer_g = MediaPlayer.create(this, R.raw.g);
            MPlayer_g.setOnCompletionListener(this);
            MPlayer_h = MediaPlayer.create(this, R.raw.h);
            MPlayer_h.setOnCompletionListener(this);
            MPlayer_i = MediaPlayer.create(this, R.raw.i);
            MPlayer_i.setOnCompletionListener(this);
            MPlayer_j = MediaPlayer.create(this, R.raw.j);
            MPlayer_j.setOnCompletionListener(this);
            MPlayer_k = MediaPlayer.create(this, R.raw.k);
            MPlayer_k.setOnCompletionListener(this);
            MPlayer_l = MediaPlayer.create(this, R.raw.l);
            MPlayer_l.setOnCompletionListener(this);
            MPlayer_m = MediaPlayer.create(this, R.raw.m);
            MPlayer_m.setOnCompletionListener(this);
            MPlayer_n = MediaPlayer.create(this, R.raw.n);
            MPlayer_n.setOnCompletionListener(this);
            MPlayer_o = MediaPlayer.create(this, R.raw.o);
            MPlayer_o.setOnCompletionListener(this);
            MPlayer_p = MediaPlayer.create(this, R.raw.p);
            MPlayer_p.setOnCompletionListener(this);
            MPlayer_q = MediaPlayer.create(this, R.raw.q);
            MPlayer_q.setOnCompletionListener(this);
            MPlayer_r = MediaPlayer.create(this, R.raw.r);
            MPlayer_r.setOnCompletionListener(this);
            MPlayer_s = MediaPlayer.create(this, R.raw.s);
            MPlayer_s.setOnCompletionListener(this);
            MPlayer_t = MediaPlayer.create(this, R.raw.t);
            MPlayer_t.setOnCompletionListener(this);
            MPlayer_u = MediaPlayer.create(this, R.raw.u);
            MPlayer_u.setOnCompletionListener(this);
            MPlayer_v = MediaPlayer.create(this, R.raw.v);
            MPlayer_v.setOnCompletionListener(this);
            MPlayer_w = MediaPlayer.create(this, R.raw.w);
            MPlayer_w.setOnCompletionListener(this);
            MPlayer_x = MediaPlayer.create(this, R.raw.x);
            MPlayer_x.setOnCompletionListener(this);
            MPlayer_y = MediaPlayer.create(this, R.raw.y);
            MPlayer_y.setOnCompletionListener(this);
            MPlayer_z = MediaPlayer.create(this, R.raw.z);
            MPlayer_z.setOnCompletionListener(this);
            MPlayer_back = MediaPlayer.create(this, R.raw.backsound_abc);
        } catch (Throwable t) {
            error_(t);
        }
        TombolIsEnabled();
    }

    private void play_back() {
        if (MPlayer_back != null && !MPlayer_back.isPlaying()) {
            MPlayer_back.setLooping(true);
            MPlayer_back.start();
        } else {
            MPlayer_back.setLooping(true);
        }
    }

    private void stop_for_back() {
        MPlayer_back.stop();
        try {
            MPlayer_back.prepare();
            MPlayer_back.seekTo(0);

        } catch (Throwable t) {
            error_(t);
        }
    }

    private void stop_back() {
        if (MPlayer_back.isPlaying()) {
            stop_for_back();
        }
    }

    private void error_(Throwable t) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Failed!").setMessage(t.toString())
                .setPositiveButton("OK", null).show();
    }

    @Override
    public void onBackPressed() {
        if (MPlayer.isPlaying() || MPlayer_back.isPlaying()) {
            MPlayer.stop();
            stop_back();
        }
        finish();
    }
}
