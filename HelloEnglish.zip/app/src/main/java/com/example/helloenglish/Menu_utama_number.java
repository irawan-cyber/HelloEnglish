package com.example.helloenglish;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.view.View;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;

public class Menu_utama_number extends Activity {
    private MediaPlayer MPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama_number);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        buka_file_suara();
    }

    @Override
    public void onResume() {
        super.onResume();
        stop_intro();
        play_intro();
    }

    private void play_intro() {
        if (MPlayer != null && !MPlayer.isPlaying()) {
            MPlayer.setLooping(true);
            MPlayer.start();
        } else {
            MPlayer.setLooping(true);
        }
    }

    private void stop() {
        MPlayer.stop();
        try {
            MPlayer.prepare();
            MPlayer.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
    }

    private void stop_intro() {
        if (MPlayer.isPlaying()) {
            stop();
        }
    }

    private void buka_file_suara() {
        try {
            MPlayer = MediaPlayer.create(this, R.raw.intro_number);
        } catch (Throwable t) {
            error_(t);
        }
    }

    private void error_(Throwable t) {
        AlertDialog.Builder pesan_error = new AlertDialog.Builder(this);
        pesan_error.setTitle("Failed!").setMessage(t.toString())
                .setPositiveButton("OK", null).show();
    }

    public void btn_01_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, S01Activity.class);
        startActivity(panggil_class);
    }

    public void btn_02_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, S02Activity.class);
        startActivity(panggil_class);
    }

    public void btn_03_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, S03Activity.class);
        startActivity(panggil_class);
    }

    public void btn_04_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, S04Activity.class);
        startActivity(panggil_class);
    }

    public void btn_05_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, S05Activity.class);
        startActivity(panggil_class);
    }

    public void btn_06_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, S06Activity.class);
        startActivity(panggil_class);
    }

    public void btn_07_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, S07Activity.class);
        startActivity(panggil_class);
    }

    public void btn_08_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, S08Activity.class);
        startActivity(panggil_class);
    }

    public void btn_09_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, S09Activity.class);
        startActivity(panggil_class);
    }

    public void btn_10_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, S10Activity.class);
        startActivity(panggil_class);
    }

    public void btn_suara_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, Menu_suara_number.class);
        startActivity(panggil_class);
    }

    public void btn_menu_Clicked(View v) {
        onBackPressed();
    }

    @Override
    public void onBackPressed() {
        stop_intro();
        Intent panggil_class = new Intent(this, Menu_utama.class);
        startActivity(panggil_class);
        finish();
    }

}
