package com.example.helloenglish;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import android.media.MediaPlayer;

public class HasilBagiActivity extends Activity {
    int data_hasil;
    String data_rinci, rincian;
    TextView teks_skor, teks_rinci;
    private MediaPlayer MPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_bagi);
        Intent panggil_class = getIntent();
        data_hasil = panggil_class.getExtras().getInt("nilai_hasil");
        data_rinci = panggil_class.getExtras().getString("rinci_jawaban");
        teks_skor = (TextView) findViewById(R.id.skor);
        teks_skor.setText(Integer.toString(data_hasil));
        teks_rinci = (TextView) findViewById(R.id.rinci);
        rincian = "Jawaban:  \n\n" + data_rinci;
        teks_rinci.setText(rincian);
        MPlayer = MediaPlayer.create(this, R.raw.pintar);
        play_hasil();
    }

    public void btn_menu_Clicked(View v) {
        onBackPressed();
    }

    public void btn_try_Clicked(View v) {
        stop_all();
        Intent panggil_class = new Intent(this, BagiActivity.class);
        startActivity(panggil_class);
        finish();
    }

    private void play_hasil() {
        MPlayer.stop();
        try {
            MPlayer.prepare();
            MPlayer.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        MPlayer.start();

    }


    private void error_(Throwable t) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Failed!").setMessage(t.toString())
                .setPositiveButton("OK", null).show();
    }

    private void stop_all() {
        if (MPlayer.isPlaying()) {
            MPlayer.stop();
        }
    }

    @Override
    public void onBackPressed() {
        stop_all();
        finish();
    }
}
