package com.example.helloenglish;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.view.View;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;

public class Menu_utama extends Activity {
    private MediaPlayer MPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        buka_file_suara();
    }

    @Override
    public void onResume() {
        super.onResume();
        stop_intro();
        play_intro();
    }

    private void play_intro() {
        if (MPlayer != null && !MPlayer.isPlaying()) {
            MPlayer.setLooping(true);
            MPlayer.start();
        } else {
            MPlayer.setLooping(true);
        }
    }

    private void stop() {
        MPlayer.stop();
        try {
            MPlayer.prepare();
            MPlayer.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
    }

    private void stop_intro() {
        if (MPlayer.isPlaying()) {
            stop();
            finish();
        }
    }

    private void buka_file_suara() {
        try {
            MPlayer = MediaPlayer.create(this, R.raw.intro_depan);
        } catch (Throwable t) {
            error_(t);
        }
    }

    private void error_(Throwable t) {
        AlertDialog.Builder pesan_error = new AlertDialog.Builder(this);
        pesan_error.setTitle("Failed!").setMessage(t.toString())
                .setPositiveButton("OK", null).show();
    }

    public void btn_abc_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, AbcActivity.class);
        startActivity(panggil_class);
    }

    public void btn_animal_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, AnimalActivity.class);
        startActivity(panggil_class);
    }

    public void btn_count_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, CountActivity.class);
        startActivity(panggil_class);
    }

    public void btn_number_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, NumberActivity.class);
        startActivity(panggil_class);
    }

    public void btn_about_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, About.class);
        startActivity(panggil_class);
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Tutup Aplikasi Hello English ?")
                .setCancelable(false)
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        Intent keluar = new Intent(Intent.ACTION_MAIN);
                        keluar.addCategory(Intent.CATEGORY_HOME);
                        keluar.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        stop_intro();
                        finish();
                        startActivity(keluar);
                        System.exit(0);
                    }
                })
                .setNegativeButton("Tidak",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        }).show();
    }
}