package com.example.helloenglish;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.view.View;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;

public class Menu_utama_count extends Activity {
    private MediaPlayer MPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama_count);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        buka_file_suara();
    }

    @Override
    public void onResume() {
        super.onResume();
        stop_intro();
        play_intro();
    }

    private void play_intro() {
        if (MPlayer != null && !MPlayer.isPlaying()) {
            MPlayer.setLooping(true);
            MPlayer.start();
        } else {
            MPlayer.setLooping(true);
        }
    }

    private void stop() {
        MPlayer.stop();
        try {
            MPlayer.prepare();
            MPlayer.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
    }

    private void stop_intro() {
        if (MPlayer.isPlaying()) {
            stop();
        }
    }

    private void buka_file_suara() {
        try {
            MPlayer = MediaPlayer.create(this, R.raw.intro_count);
        } catch (Throwable t) {
            error_(t);
        }
    }

    private void error_(Throwable t) {
        AlertDialog.Builder pesan_error = new AlertDialog.Builder(this);
        pesan_error.setTitle("Failed!").setMessage(t.toString())
                .setPositiveButton("OK", null).show();
    }

    public void btn_plus_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, PlusActivity.class);
        startActivity(panggil_class);
    }

    public void btn_minus_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, MinusActivity.class);
        startActivity(panggil_class);
    }

    public void btn_kali_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, KaliActivity.class);
        startActivity(panggil_class);
    }

    public void btn_bagi_Clicked(View v) {
        stop_intro();
        Intent panggil_class = new Intent(this, BagiActivity.class);
        startActivity(panggil_class);
    }

    public void btn_menu_Clicked(View v) {
        onBackPressed();
    }

    @Override
    public void onBackPressed() {
        stop_intro();
        Intent panggil_class = new Intent(this, Menu_utama.class);
        startActivity(panggil_class);
        finish();
    }

}
