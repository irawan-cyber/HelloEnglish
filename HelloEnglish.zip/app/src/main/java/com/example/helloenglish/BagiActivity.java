package com.example.helloenglish;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.media.MediaPlayer;

public class BagiActivity extends Activity {

    private MediaPlayer MPlayer_01;
    private MediaPlayer MPlayer_02;

    public int nilai_01, nilai_02, nilai_03, nilai_04, nilai_05, nilai_06,
            nilai_07, nilai_08, nilai_09, nilai_10, jumlah_nilai;
    public static int nilai = 0;
    public Spinner menu_jawab_01, menu_jawab_02, menu_jawab_03, menu_jawab_04,
            menu_jawab_05, menu_jawab_06, menu_jawab_07, menu_jawab_08,
            menu_jawab_09, menu_jawab_10;
    public ImageButton cek_nilai;
    public static int nilai_total = 0;
    public String jawaban, hasil_jawaban, isi_jawaban;
    public static String data_jawaban = "";
    int[] kunci = {1, 1, 2, 1, 2, 1, 2, 1, 1, 1};
    int[] soal = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    String[] jawaban_01 = {" Pilih jawaban", "A. 7", "B. 6"};
    String[] jawaban_02 = {" Pilih jawaban", "A. 3", "B. 4"};
    String[] jawaban_03 = {" Pilih jawaban", "A. 3", "B. 2"};
    String[] jawaban_04 = {" Pilih jawaban", "A. 9", "B. 8"};
    String[] jawaban_05 = {" Pilih jawaban", "A. 3", "B. 2"};
    String[] jawaban_06 = {" Pilih jawaban", "A. 2", "B. 1"};
    String[] jawaban_07 = {" Pilih jawaban", "A. 7", "B. 8"};
    String[] jawaban_08 = {" Pilih jawaban", "A. 1", "B. 2"};
    String[] jawaban_09 = {" Pilih jawaban", "A. 1", "B. 2"};
    String[] jawaban_10 = {" Pilih jawaban", "A. 3", "B. 2"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bagi);
        aktif();
        menu_jawab_01 = (Spinner) findViewById(R.id.jwb_01);
        menu_jawab_02 = (Spinner) findViewById(R.id.jwb_02);
        menu_jawab_03 = (Spinner) findViewById(R.id.jwb_03);
        menu_jawab_04 = (Spinner) findViewById(R.id.jwb_04);
        menu_jawab_05 = (Spinner) findViewById(R.id.jwb_05);
        menu_jawab_06 = (Spinner) findViewById(R.id.jwb_06);
        menu_jawab_07 = (Spinner) findViewById(R.id.jwb_07);
        menu_jawab_08 = (Spinner) findViewById(R.id.jwb_08);
        menu_jawab_09 = (Spinner) findViewById(R.id.jwb_09);
        menu_jawab_10 = (Spinner) findViewById(R.id.jwb_10);
        cek_nilai = (ImageButton) findViewById(R.id.Btn_check);
        ArrayAdapter<String> list_jawab_01 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, jawaban_01);
        list_jawab_01
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_jawab_01.setAdapter(list_jawab_01);
        menu_jawab_01.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                nilai_01 = menu_jawab_01.getSelectedItemPosition();
                switch (arg2) {
                    case 0:
                        stop_all();
                        break;
                    case 1:
                        play_01();
                        break;
                    case 2:
                        play_02();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        ArrayAdapter<String> list_jawab_02 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, jawaban_02);
        list_jawab_02
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_jawab_02.setAdapter(list_jawab_02);
        menu_jawab_02.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                nilai_02 = menu_jawab_02.getSelectedItemPosition();
                switch (arg2) {
                    case 0:
                        stop_all();
                        break;
                    case 1:
                        play_01();
                        break;
                    case 2:
                        play_02();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        ArrayAdapter<String> list_jawab_03 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, jawaban_03);
        list_jawab_03
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_jawab_03.setAdapter(list_jawab_03);
        menu_jawab_03.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                nilai_03 = menu_jawab_03.getSelectedItemPosition();
                switch (arg2) {
                    case 0:
                        stop_all();
                        break;
                    case 1:
                        play_02();
                        break;
                    case 2:
                        play_01();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        ArrayAdapter<String> list_jawab_04 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, jawaban_04);
        list_jawab_04
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_jawab_04.setAdapter(list_jawab_04);
        menu_jawab_04.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                nilai_04 = menu_jawab_04.getSelectedItemPosition();
                switch (arg2) {
                    case 0:
                        stop_all();
                        break;
                    case 1:
                        play_01();
                        break;
                    case 2:
                        play_02();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        ArrayAdapter<String> list_jawab_05 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, jawaban_05);
        list_jawab_05
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_jawab_05.setAdapter(list_jawab_05);
        menu_jawab_05.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                nilai_05 = menu_jawab_05.getSelectedItemPosition();
                switch (arg2) {
                    case 0:
                        stop_all();
                        break;
                    case 1:
                        play_02();
                        break;
                    case 2:
                        play_01();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        ArrayAdapter<String> list_jawab_06 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, jawaban_06);
        list_jawab_06
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_jawab_06.setAdapter(list_jawab_06);
        menu_jawab_06.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                nilai_06 = menu_jawab_06.getSelectedItemPosition();
                switch (arg2) {
                    case 0:
                        stop_all();
                        break;
                    case 1:
                        play_01();
                        break;
                    case 2:
                        play_02();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        ArrayAdapter<String> list_jawab_07 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, jawaban_07);
        list_jawab_07
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_jawab_07.setAdapter(list_jawab_07);
        menu_jawab_07.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                nilai_07 = menu_jawab_07.getSelectedItemPosition();
                switch (arg2) {
                    case 0:
                        stop_all();
                        break;
                    case 1:
                        play_02();
                        break;
                    case 2:
                        play_01();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        ArrayAdapter<String> list_jawab_08 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, jawaban_08);
        list_jawab_08
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_jawab_08.setAdapter(list_jawab_08);
        menu_jawab_08.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                nilai_08 = menu_jawab_08.getSelectedItemPosition();
                switch (arg2) {
                    case 0:
                        stop_all();
                        break;
                    case 1:
                        play_01();
                        break;
                    case 2:
                        play_02();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        ArrayAdapter<String> list_jawab_09 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, jawaban_09);
        list_jawab_09
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_jawab_09.setAdapter(list_jawab_09);
        menu_jawab_09.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                nilai_09 = menu_jawab_09.getSelectedItemPosition();
                switch (arg2) {
                    case 0:
                        stop_all();
                        break;
                    case 1:
                        play_01();
                        break;
                    case 2:
                        play_02();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        ArrayAdapter<String> list_jawab_10 = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, jawaban_10);
        list_jawab_10
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        menu_jawab_10.setAdapter(list_jawab_10);
        menu_jawab_10.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                nilai_10 = menu_jawab_10.getSelectedItemPosition();
                switch (arg2) {
                    case 0:
                        stop_all();
                        break;
                    case 1:
                        play_01();
                        break;
                    case 2:
                        play_02();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }

    public void btn_check_Clicked(View v) {
        int pilihan_jawaban[] = {nilai_01, nilai_02, nilai_03, nilai_04,
                nilai_05, nilai_06, nilai_07, nilai_08, nilai_09, nilai_10};
        int nomor_pilihan;
        for (int i = 0; i < kunci.length; i++) {
            if (pilihan_jawaban[i] == 1) {
                jawaban = " A ";
            } else if (pilihan_jawaban[i] == 2) {
                jawaban = " B ";
            } else {
                jawaban = " - ";
            }
            if (kunci[i] == 1) {
                isi_jawaban = "A";
            } else if (kunci[i] == 2) {
                isi_jawaban = "B";
            } else {
                isi_jawaban = "Tidak dijawab";
            }
            if (pilihan_jawaban[i] == kunci[i]) {
                nilai_total = nilai_total + 10;
                hasil_jawaban = jawaban + " (Benar) = " + isi_jawaban
                        + ",   (Nilai = 10)\n";
            } else {
                hasil_jawaban = jawaban + " (Salah) = " + isi_jawaban
                        + ",   (Nilai = 0)\n";
            }
            nomor_pilihan = i + 1;
            data_jawaban = data_jawaban + Integer.toString(nomor_pilihan)
                    + ". " + hasil_jawaban;
        }
        stop_all();
        Intent panggil_class = new Intent(this, HasilBagiActivity.class);
        panggil_class.putExtra("nilai_hasil", nilai_total);
        panggil_class.putExtra("rinci_jawaban", data_jawaban);
        startActivity(panggil_class);
        finish();
        System.exit(0);
    }

    private void play_01() {
        stop_all();
        try {
            MPlayer_01.prepare();
            MPlayer_01.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        MPlayer_01.start();

    }

    private void play_02() {
        stop_all();
        try {
            MPlayer_02.prepare();
            MPlayer_02.seekTo(0);
        } catch (Throwable t) {
            error_(t);
        }
        MPlayer_02.start();

    }

    private void stop_all() {
        MPlayer_01.stop();
        MPlayer_02.stop();
    }

    private void aktif() {
        try {
            MPlayer_01 = MediaPlayer.create(this, R.raw.benar);
            MPlayer_02 = MediaPlayer.create(this, R.raw.salah);
        } catch (Throwable t) {
            error_(t);
        }
    }

    private void error_(Throwable t) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Failed!").setMessage(t.toString())
                .setPositiveButton("OK", null).show();
    }

    @Override
    public void onBackPressed() {
        if (MPlayer_01.isPlaying() || MPlayer_02.isPlaying()) {
            stop_all();
        }
        finish();
    }
}